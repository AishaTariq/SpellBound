package endsemesterproject;

import javafx.animation.AnimationTimer;

public class UnicornBullet extends Bullet {

    // Constructor with one Unicorn argument
    UnicornBullet(Unicorn unicorn) {
        super(ImageCollection.getUnicornBulletImage(), unicorn);  // Call to constructor of super class
        // Setting the x and y Coordinates of the bullet such that it starts at the horn of the unicorn
        setxCoord(getShooter().getCharacterIV().getLayoutX() + 20);
        setyCoord(getShooter().getCharacterIV().getLayoutY());
    }

    // Overriding the move method in item to make the unicorn bullet move up
    @Override
    public void move() {
        AnimationTimer bulletLoop = new AnimationTimer() {
            @Override
            public void handle(long l) {
                // Condition to make the loop stop
                if(isDestroyed() || Item.isNotMoving())
                    this.stop();
                // Updating the yCoord of the unicorn bullet to 3 pixels up
                setyCoord(getItemIV().getLayoutY() - 3);
                // If the unicorn bullet goes out of the screen, removing it from the pane
                if( getItemIV().getLayoutY()<=-getItemIV().getImage().getHeight()) {
                    setDestroyed(true);
                    getLevelPane().getChildren().remove(getItemIV());
                }
                // Moving the ItemIV to the new yCoord
                getItemIV().setLayoutY(getyCoord());
            }
        };
        bulletLoop.start();  // Starting the loop
    }
}  // Ending brace of class UnicornBullet
