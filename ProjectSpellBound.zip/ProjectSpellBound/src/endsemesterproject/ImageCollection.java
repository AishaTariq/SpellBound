package endsemesterproject;

import javafx.scene.image.Image;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/** This is an abstract class that contains all the Images required for the game and their getter methods**/
public abstract class ImageCollection {
    private static FileInputStream input;  // FileInputStream object for reading images from the files
    private static Image tempImage;  // A temporary image for the createImage method
    // All the images of the game
    private static Image background = createImage("src/endsemesterproject/Images/homepage.PNG");
    private static Image movingBackground = createImage("src/endsemesterproject/Images/moving background.png");
    private static Image livesImage = createImage("src/endsemesterproject/Images/lives icon.png");
    private static Image controlsImage = createImage("src/endsemesterproject/Images/controls.PNG");
    private static Image creditsImage = createImage("src/endsemesterproject/Images/credits.PNG");
    private static Image unicornLeftImage = createImage("src/endsemesterproject/Images/unicorn left.png");
    private static Image unicornRightImage = createImage("src/endsemesterproject/Images/unicorn right.png");
    private static Image unicornBulletImage = createImage("src/endsemesterproject/Images/unicornbullet.png");
    private static Image witchImage = createImage("src/endsemesterproject/Images/witch.png");
    private static Image witchBulletImage = createImage("src/endsemesterproject/Images/witchbullet.png");
    private static Image powerupImage = createImage("src/endsemesterproject/Images/powerup.png");
    private static Image cauldronImage = createImage("src/endsemesterproject/Images/cauldron.png");
    private static Image pumpkinImage = createImage("src/endsemesterproject/Images/pumpkin.png");
    private static Image homeIcon = createImage("src/endsemesterproject/Images/home button.png");
    private static Image controlsIcon = createImage("src/endsemesterproject/Images/control button.png");
    private static Image playIcon = createImage("src/endsemesterproject/Images/play button.png");
    private static Image introIcon = createImage("src/endsemesterproject/Images/intro button.png");
    private static Image creditsIcon = createImage("src/endsemesterproject/Images/credits button.png");
    private static Image winGameImage = createImage("src/endsemesterproject/Images/unicornTribe.png");

    // Method to create an Image
    private static Image createImage(String imageFileName) {
        try {
            input = new FileInputStream(imageFileName);  // Creating new FileInputStream for the given file name
            tempImage = new Image(input);  // Creating the Image
        }
        // Handling exception
        catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("Error loading image.");
        }
        // Closing the FileInputStream in the Finally block
        finally {
            try {
                if (input != null)
                    input.close();  // Close the FileInputStream input if it is not null
            }
            // Catching exception
            catch (IOException e) {
                e.printStackTrace();
                System.out.println("Error closing FileInputStream.");
            }
        }
        return tempImage;
    }

    // Getter methods for all the Images in ImageCollection
    public static Image getBackground() {
        return background;
    }

    public static Image getMovingBackground() {
        return movingBackground;
    }

    public static Image getLivesImage() {
        return livesImage;
    }

    public static Image getControlsImage() {
        return controlsImage;
    }

    public static Image getCreditsImage() {
        return creditsImage;
    }

    public static Image getUnicornLeftImage() {
        return unicornLeftImage;
    }

    public static Image getUnicornRightImage() {
        return unicornRightImage;
    }

    public static Image getUnicornBulletImage() {
        return unicornBulletImage;
    }

    public static Image getWitchImage() {
        return witchImage;
    }

    public static Image getWitchBulletImage() {
        return witchBulletImage;
    }

    public static Image getPowerupImage() { return powerupImage; }

    public static Image getCauldronImage() { return cauldronImage; }

    public static Image getPumpkinImage() { return pumpkinImage; }

    public static Image getHomeIcon() { return homeIcon; }

    public static Image getControlsIcon() { return controlsIcon; }

    public static Image getPlayIcon() { return playIcon; }

    public static Image getCreditsIcon() { return creditsIcon; }

    public static Image getIntroIcon() { return introIcon; }

    public static Image getWinGameImage() {
        return winGameImage;
    }
}  // Ending brace of class ImageCollection
