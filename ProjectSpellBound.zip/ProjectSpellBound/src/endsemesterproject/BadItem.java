package endsemesterproject;

import javafx.scene.image.Image;
import javafx.scene.layout.Pane;

/** An abstract class for items that are destructive to characters **/
public abstract class BadItem extends Item {
    // Constructor with two arguments
    public BadItem(Image itemImage, Pane levelPane) {
        super(itemImage, levelPane);  // Call to constructor of super class
    }

    // Constructor with one Pane argument
    public BadItem(Pane levelPane) {
        super(levelPane);  // Call to constructor of super class
    }

    // Method to detect collisions of the bad item with unicorn bullets
    public void detectCollisionWithUnicornBullets(Unicorn unicorn) {
        for(int i = 0; i< unicorn.getBulletsArray().length; i++) {
            // If the bullet in the array at i is not null
            if(unicorn.getBulletsArray()[i] != null)
                // If both the bad item and the unicorn bullet are not destroyed and collide on the pane
                if (!this.isDestroyed() && !unicorn.getBulletsArray()[i].isDestroyed() && unicorn.getBulletsArray()[i].getItemIV().getBoundsInParent().intersects(this.getItemIV().getBoundsInParent())) {
                this.setDestroyed(true);  // Setting isDestroyed of the bad item to true
                unicorn.getBulletsArray()[i].setDestroyed(true);  // Setting the isDestroyed of the unicorn bullet to true
                // Removing both the items from the pane
                getLevelPane().getChildren().remove(this.getItemIV());
                unicorn.getBulletsArray()[i].getLevelPane().getChildren().remove(unicorn.getBulletsArray()[i].getItemIV());
            }
            // If the bad item has already been destroyed, stop checking for collisions with the rest of the array
            if(this.isDestroyed())
                break;
        }
    }
}  // Ending brace of class BadItem
