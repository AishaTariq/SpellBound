package endsemesterproject;

/** Class WitchBullet for bullets shot by a Witch **/
public class WitchBullet extends Bullet {
    // Constructor with one Witch argument
    WitchBullet(Witch witch) {
        super(ImageCollection.getWitchBulletImage(), witch);  // Call to constructor of super class
        // Setting the x and y Coordinates of the bullet such that it starts at the wand of the witch
        setxCoord(getShooter().getCharacterIV().getLayoutX() - 10);
        setyCoord(getShooter().getCharacterIV().getLayoutY() + 40);
    }
}