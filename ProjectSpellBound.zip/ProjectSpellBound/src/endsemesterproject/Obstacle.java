package endsemesterproject;

import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

/** Class for bad items that are dropped from the top of the pane and have two different types **/
public class Obstacle extends BadItem {
    // Constants for creating the itemIV of the obstacle
    final static int CAULDRON_OBSTACLE = 1;  // A Cauldron Obstacle type
    final static int PUMPKIN_OBSTACLE = 2;  // A pumpkin Obstacle type
    private int type;  // Type of the obstacle

    // Constructor with 2 arguments
    Obstacle(int type, Pane pane){
        super(pane);  // Call to method of super class
        createRandomStartPosition();  // Creating a random starting position for the obstacle
        this.type = type;  // Assigning the type
        // Setting the itemIV based on the type of the obstacle
        switch (this.type) {
            case CAULDRON_OBSTACLE:
                setItemIV(new ImageView(ImageCollection.getCauldronImage()));
                break;
            case PUMPKIN_OBSTACLE:
                setItemIV(new ImageView(ImageCollection.getPumpkinImage()));
                break;
        }
    }
}  // Ending brace of the class Obstacle


