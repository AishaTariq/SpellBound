package endsemesterproject;

import javafx.animation.AnimationTimer;
import javafx.scene.layout.Pane;

/** Class Witch that inherits from the class Character **/
public class Witch extends Character {

    // Constructor with one pane argument
    public Witch(Pane pane) {
        super(ImageCollection.getWitchImage(), pane);  // Call to constructor of super class
    }

    // Method to make the witch shoot a bullet at a given unicorn
    public void shootBullets(Unicorn unicorn) {
        WitchBullet witchBullet = new WitchBullet(this);  // creating a new WitchBullet
        witchBullet.addToPane();  // adding it to the pane
        witchBullet.move();  // making it move on the pane
        // Loop to detect collisions of the witch bullet with the unicorn and the unicorn's bullets
        AnimationTimer collisionLoop = new AnimationTimer() {
            @Override
            public void handle(long l) {
                // Condition to stop the loop
                if(witchBullet.isDestroyed() || Character.isNotShooting())
                    this.stop();
                witchBullet.detectCollisionWithUnicornBullets(unicorn);  // Detecting collisions with unicorn bullets
                witchBullet.detectCollisionWithCharacter(unicorn);  // Detecting collisions with unicorn

            }
        };
        collisionLoop.start();  // Starting the loop
    }

    // Method to make the witch move left
    public void moveLeft(){
        // Changing xCoord one pixel to the left
        setxCoord(getCharacterIV().getLayoutX() - 1);
        getCharacterIV().setLayoutX(getxCoord());
    }

    // Method to make the witch move right
    public void moveRight(){
        // Changing xCoord one pixel to the right
        setxCoord(getCharacterIV().getLayoutX() + 1);
        getCharacterIV().setLayoutX(getxCoord());
    }

    // Method for what happens when the Witch collides with an Item
    @Override
    public void onCollision(Item item) {
        SoundCollection.playWitchDestroyed();  // Playing the witch destroyed audio
        this.setIsDead(true);  // Setting isDead of the witch to true i.e the witch dies
        this.getCharacterPane().getChildren().remove(this.getCharacterIV());  // Removing the witch from the pane
    }
}  // Ending brace of class Witch