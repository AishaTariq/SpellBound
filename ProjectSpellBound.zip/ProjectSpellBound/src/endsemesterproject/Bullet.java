package endsemesterproject;

import javafx.scene.image.Image;

/** Abstract class Bullet for bad items (bullets) that are shot by characters **/
public abstract class Bullet extends BadItem {
    private Character shooter;  // The character that the bullet has been shot by

    // Constructor with two arguments
    public Bullet(Image itemImage, Character shooter) {
        super(itemImage, shooter.getCharacterPane());  // Call to constructor of super class
        this.shooter = shooter;  // Assigning the shooter
    }

    // Getter method for the shooter
    public Character getShooter() {
        return shooter;
    }
}  // Ending brace of class Bullet
