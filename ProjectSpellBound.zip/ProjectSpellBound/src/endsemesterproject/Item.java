package endsemesterproject;

import javafx.animation.AnimationTimer;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

import java.util.Random;

/** Abstract class Item that implements CollidableItem for all the items to be used in the game**/
public abstract class Item implements CollidableItem {
    private boolean isDestroyed;  // Boolean variable to show if the Item is destroyed or not
    private ImageView itemIV;  // ImageView of the Item
    private Pane levelPane;  // Pane to which the Item is added
    private double xCoord;  // x coordinate of the Item
    private double yCoord;  // y coordinate of the Item
    private static boolean isNotMoving;  // Boolean variable to control whether the Item is moving or not

    // Constructor with 2 arguments
    public Item(Image itemImage, Pane levelPane) {
        this(levelPane);  // Call to constructor of Item class using this
        itemIV = new ImageView(itemImage);  // Initializing the ImageView
    }

    // Constructor with one Pane argument
    public Item(Pane levelPane) {
        this.levelPane = levelPane;  // Initializing the level pane
        // Setting control booleans to default
        this.isDestroyed = false;
        Item.isNotMoving = false;
    }

    // Implementation of method addToPane() of CollidableItem which adds the ItemIV to the pane
    @Override
    public void addToPane() {
        levelPane.getChildren().add(itemIV);
        itemIV.setLayoutX(getxCoord());  // Setting the xLayout of the itemIV at the assigned x coordinate
        itemIV.setLayoutY(getyCoord());  // Setting the yLayout of the itemIV at the assigned y coordinate
    }

    // Implementation of method move() of CollidableItem which makes the itemIV move on the pane
    @Override
    public void move() {
        // Loop to make the Item move
        AnimationTimer movementLoop = new AnimationTimer() {
            @Override
            public void handle(long l) {
                // Condition to stop the loop
                if(isDestroyed() || Item.isNotMoving())
                    this.stop();
                // Updating the yCoord of the Item to 3 pixels down
                setyCoord(getItemIV().getLayoutY() + 3);
                // If the item goes out of the screen, removing it from the pane
                if( getItemIV().getLayoutY()>=getLevelPane().getHeight()-3) {
                    setDestroyed(true);
                    getLevelPane().getChildren().remove(getItemIV());
                }
                // Moving the ItemIV to the new yCoord
                getItemIV().setLayoutY(getyCoord());
            }
        };
        movementLoop.start();  // Starting the loop
    }

    // Method to assign a random starting position for the item at the top of the pane
    public void createRandomStartPosition() {
        Random rand = new Random();  // Random object for generating random numbers
        // Assigning a random x layout to the item such that it doesnt go out of the pane
        double x = rand.nextInt((int)(levelPane.getWidth() - 170)) + 50;
        setxCoord(x);
        setyCoord(0);  // Setting the y layout to 0 so that the item starts at the top of the pane
    }

    // Implementation of method of CollidableItem which detects collisions between the Item and a character
    @Override
    public void detectCollisionWithCharacter(Character character) {
        // If the Item is not destroyed yet and the character is not dead and they collide on the pane
        if(!this.isDestroyed() && !character.isDead() && character.getCharacterIV().getBoundsInParent().intersects(this.getItemIV().getBoundsInParent())) {
            this.setDestroyed(true);  // Setting isDestroyed of the Item to true
            character.onCollision(this);  // Calling method onCollision of the character
            getLevelPane().getChildren().remove(this.getItemIV());  // Removing the item from the pane
        }
    }

    // Getter and Setter methods for the properties of the class
    public boolean isDestroyed() {
        return isDestroyed;
    }

    public void setDestroyed(boolean destroyed) {
        isDestroyed = destroyed;
    }

    public ImageView getItemIV() {
        return itemIV;
    }

    public void setItemIV(ImageView itemIV) {
        this.itemIV = itemIV;
    }

    public double getxCoord() {
        return xCoord;
    }

    public void setxCoord(double xCoord) {
        this.xCoord = xCoord;
    }

    public double getyCoord() {
        return yCoord;
    }

    public void setyCoord(double yCoord) {
        this.yCoord = yCoord;
    }

    public Pane getLevelPane() {
        return levelPane;
    }

    public static boolean isNotMoving() {
        return isNotMoving;
    }

    public static void setNotMoving(boolean isNotMoving) {
        Item.isNotMoving = isNotMoving;
    }
}  // Ending brace of class Item
