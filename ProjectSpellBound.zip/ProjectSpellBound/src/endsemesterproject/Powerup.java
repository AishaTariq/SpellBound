package endsemesterproject;

import javafx.scene.layout.Pane;

/** Class Powerup for items that are helpful to characters **/
public class Powerup extends Item {

    Powerup(Pane pane){
        super(ImageCollection.getPowerupImage(), pane);  // Call to constructor of super class
        createRandomStartPosition();  // Creating a random starting position for the powerup
    }
}  // Ending brace of class Powerup