package endsemesterproject;

import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.io.File;

/** This is an abstract class that contains all the sound effects required for the game and their getter methods**/
public abstract class SoundCollection {
    private static AudioClip tempAudio;  // AudioClip for the createAudioClip() Method
    private static MediaPlayer tempMediaPlayer;  // MediaPlayer for the createMediaPlayer() Method
    // All the sound effects of the game
    private static AudioClip unicornLoseLife = createAudio("src/endsemesterproject/Sound Effects/unicorn life.mp3");
    private static AudioClip unicornDestroyed = createAudio("src/endsemesterproject/Sound Effects/unicorn dying.mp3");
    private static AudioClip unicornShoot = createAudio("src/endsemesterproject/Sound Effects/unicorn shoot.mp3");
    private static AudioClip witchDestroyed = createAudio("src/endsemesterproject/Sound Effects/witch destroyed.mp3");
    private static AudioClip pickupPowerUp = createAudio("src/endsemesterproject/Sound Effects/powerup audio.mp3");
    private static AudioClip levelTransition = createAudio("src/endsemesterproject/Sound Effects/level transition.mp3");
    private static AudioClip gameOver = createAudio("src/endsemesterproject/Sound Effects/game over.mp3");
    private static AudioClip gameWon = createAudio("src/endsemesterproject/Sound Effects/win game.mp3");
    private static AudioClip homepageAudio = createAudio("src/endsemesterproject/Sound Effects/homepage audio.mp3");
    private static MediaPlayer introNarration = createMedia("src/endsemesterproject/Sound Effects/narration.mp3");
    private static MediaPlayer introMusic = createMedia("src/endsemesterproject/Sound Effects/intro music.mp3");

    // Method to create an audio clip
    private static AudioClip createAudio(String audioPath){
        try {
            tempAudio = new AudioClip(new File(audioPath).toURI().toString());  // creating AudioClip using given path
        }
        // Catching exception
        catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error creating audio clip.");
        }
        return tempAudio;
    }

    // Method to create a media player
    private static MediaPlayer createMedia(String mediaPath){
        try {
            Media narrationAudio = new Media(new File(mediaPath).toURI().toString());  // creating Media
            tempMediaPlayer = new MediaPlayer(narrationAudio);  // creating MediaPlayer
        }
        // Catching Exception
        catch(Exception e) {
            e.printStackTrace();
            System.out.println("Error creating media player.");
        }
        return tempMediaPlayer;
    }

    // Methods to Play all the AudioClips and MediaPlayers of SoundCollection
    public static void playUnicornLoseLife() {
        unicornLoseLife.play();
    }

    public static void playUnicornDestroyed() { unicornDestroyed.play(); }

    public static void playUnicornShoot() {
        unicornShoot.play();
    }

    public static void playWitchDestroyed() { witchDestroyed.play(); }

    public static void playPickupPowerup() {
        pickupPowerUp.play();
    }

    public static void playLevelTransition() {
        levelTransition.play();
    }

    public static void playGameOver() {
        gameOver.play();
    }

    public static void playGameWon() {
        gameWon.play();
    }

    public static void playIntroNarration() {
        introNarration.play();
    }

    // Method to stop the Intro Narration
    public static void stopIntroNarration() {
        introNarration.stop();
    }

    // Method to play the homepage audio over and over until stopped
    public static void playHomepageAudio() {
        homepageAudio.setCycleCount(AudioClip.INDEFINITE);
        homepageAudio.play();
    }

    // Method to stop the homepage audio
    public static void stopHomepageAudio() { homepageAudio.stop(); }

    // Method to play the intro music over and over until stopped
    public static void playIntroMusic() {
        introMusic.setCycleCount(AudioClip.INDEFINITE);
        introMusic.play();
    }

    // Method to stop the intro music
    public static void stopIntroMusic() {
        introMusic.stop();
    }

}  // Ending brace of class SoundCollection
