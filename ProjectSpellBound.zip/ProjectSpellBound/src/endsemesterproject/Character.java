package endsemesterproject;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

/** Abstract class character for the characters in the game to be inherited by classes Unicorn and Witch **/
public abstract class Character {
    private ImageView characterIV;  // ImageView of the character
    private double xCoord;  // X Coordinate of the character on the screen
    private double yCoord;  // Y Coordinate of the character on the screen
    private Pane characterPane;  // Pane to which the characterIV is added
    private boolean isDead;  // Boolean variable to show if the character is dead or alive
    private static boolean isNotShooting;  // Boolean variable to control whether the character is shooting or not

    // Constructor with 2 arguments: The image for the characterIV and the pane of the character
    public Character(Image imageCharacter, Pane pane){
        characterIV = new ImageView(imageCharacter);  // Initializing the characterIV
        isDead = false;  // Initializing isDead to false when the Character object is created
        characterPane = pane;  // Initializing the characterPane
        xCoord = characterIV.getLayoutX();  // Initializing the xCoord
        yCoord = characterIV.getLayoutY();  // Initializing the yCoord
    }

    // Abstract method for what happens when the character collides with an Item, to be implemented in inheriting classes
    public abstract void onCollision(Item item);

    // Getter method for isNotShooting
    public static boolean isNotShooting() {
        return isNotShooting;
    }

    // Setter method for isNotShooting
    public static void setNotShooting(boolean notShooting) {
        Character.isNotShooting = notShooting;
    }

    // Getter method for isDead
    public boolean isDead() {
        return isDead;
    }

    // Setter method for isDead
    public void setIsDead(boolean dead) {
        isDead = dead;
    }

    // Getter method for characterIV
    public ImageView getCharacterIV() {
        return characterIV;
    }

    // Getter method for xCoord
    public double getxCoord() {
        return xCoord;
    }

    // Setter method for xCoord
    public void setxCoord(double xCoord) {
        this.xCoord = xCoord;
    }

    // Getter method for characterPane
    public Pane getCharacterPane() {
        return characterPane;
    }

}  // Ending brace of class Character