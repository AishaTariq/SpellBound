package endsemesterproject;

// Interface for an object that moves on a pane and collides with Characters
public interface CollidableItem {
    void addToPane();  // Method to add the object to the pane
    void move();  // Method to make the object move on the pane
    void detectCollisionWithCharacter(Character character);  // Method to detect collision of the object with a Character
}  // Ending brace of CollidableItem

