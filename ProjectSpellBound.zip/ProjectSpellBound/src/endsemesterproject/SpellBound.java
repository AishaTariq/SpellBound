/** END OF SEMESTER PROJECT: SPELLBOUND
 * GROUP MEMBERS:
 * Aisha Tariq - 289885
 * Sumaiyyah Tahir - 284482
 * Khadija Binte Bilal - 282646
 * CLASS: BSCS-9
 * SECTION: A
 * COURSE: CS-212 Object Oriented Programming
 * INSTRUCTOR: Dr. Pakeeza Akram
**/

package endsemesterproject;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.util.Random;

// Main Class that extends Application
public class SpellBound extends Application {
    private Stage gameStage;  // primaryStage of Application
    private Scene homePageScene;  // Scene for the Home Page
    private StackPane homePagePane;  // StackPane for the Home Page
    private final int GAME_WINDOW_WIDTH = 933;  // Width of the Game Window
    private final int GAME_WINDOW_HEIGHT = 700;  // Height of the Game Window
    private boolean stopBackground;  // boolean variable to make the background stop moving
    private boolean gameWon;  // boolean variable to see if the game has been won yet
    private Unicorn unicornPlayer;  // Main Unicorn character that the player will control
    // Array of Witch objects that will be the enemies in the levels
    private Witch[] witchArray1 = new Witch[5];
    private Witch[] witchArray2 = new Witch[5];
    private Witch[] witchArray3 = new Witch[5];
    private Witch[] witchArray4 = new Witch[5];

    @Override
    public void start(Stage primaryStage) {
        gameStage = primaryStage;  // Initializing the game stage
        gameStage.setTitle("SPELLBOUND");  // Title of the Stage i.e the Title of Our Game
        gameStage.centerOnScreen();  // Centering the stage
        drawHomePage();  // Calling method to create the Home Page
        gameStage.setResizable(false);  // Making the game window non - resizable
        gameStage.show();  // Making the stage visible
    }

    // Method that creates the home page scene and sets it to the stage
    private void drawHomePage() {
        VBox buttonsPane = new VBox();  // Pane for the Home Page buttons
        homePagePane = new StackPane();  // Outer Pane of the Home Page
        // Creating Home Page buttons
        Button play = createButtons("Play", ImageCollection.getPlayIcon());  // Play Button
        Button intro = createButtons("Intro", ImageCollection.getIntroIcon());  // Introduction Button
        Button controls = createButtons("Controls", ImageCollection.getControlsIcon());  // Controls Button
        Button credits = createButtons("Credits", ImageCollection.getCreditsIcon());  // Credits Button
        // Adding event handlers for the home page buttons
        play.setOnAction(e -> {
            SoundCollection.stopHomepageAudio();  // Stop the home page AudioClip
            SoundCollection.playLevelTransition();  // Play the level transition AudioClip
            displayMessage("LEVEL 1", "BEGIN GAME", 1);  // Display message to begin level 1
        });
        intro.setOnAction(e ->{
            SoundCollection.stopHomepageAudio();  // Stop the home page AudioClip
            beginIntroduction();  // Begin the Introduction to the game
        });
        controls.setOnAction(e -> displayPaneOnHome(ImageCollection.getControlsImage()));  // Display the controls
        credits.setOnAction(e -> displayPaneOnHome(ImageCollection.getCreditsImage()));  // Display the credits
        // Adding buttons to the buttons pane
        buttonsPane.getChildren().addAll(play, intro, controls, credits);
        // Positioning the buttons pane on the screen
        buttonsPane.setAlignment(Pos.CENTER);
        buttonsPane.setTranslateY(25);
        // Setting the spacing between the buttons
        buttonsPane.setSpacing(25);
        buttonsPane.setPrefSize(100, 200);
        // Creating an image for the background
        BackgroundImage bgImage = new BackgroundImage(ImageCollection.getBackground(), BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                new BackgroundSize(100, 100, true, true, true, false));
        // Creating the background for the Home Page
        Background bg = new Background(bgImage);
        // Setting the size of the outer home page pane
        homePagePane.setPrefSize(GAME_WINDOW_WIDTH, GAME_WINDOW_HEIGHT);
        // Adding the background and the buttons pane to the home page pane
        homePagePane.setBackground(bg);
        homePagePane.getChildren().add(buttonsPane);
        // Creating the home page scene with the home page pane
        homePageScene = new Scene(homePagePane, GAME_WINDOW_WIDTH, GAME_WINDOW_HEIGHT);
        // Playing the home page AudioClip
        SoundCollection.playHomepageAudio();
        // Setting the home page scene to the game stage
        gameStage.setScene(homePageScene);
    }

    // Method to create a button for the home page from the given button name and icon
    private Button createButtons(String buttonName, Image buttonIcon){
        // Creating the ImageView for the icon on the button
        ImageView buttonIconIV = new ImageView(buttonIcon);
        // Preserving the buttons original width to height ratio
        buttonIconIV.setPreserveRatio(true);
        // Setting the Width and Height of the button
        buttonIconIV.setFitHeight(25);
        buttonIconIV.setFitWidth(25);
        // Creating Button object
        Button button = new Button("" + buttonName, buttonIconIV);
        // Positioning the button icon to the right of the button name
        button.setContentDisplay(ContentDisplay.RIGHT);
        // Setting the font of the button
        button.setFont(Font.font("Harrington", 15));
        // Setting the color of the button to lime green
        button.setStyle("-fx-background-color: #32CD32");
        // Making the button not be automatically focused
        button.setFocusTraversable(false);
        // Changing the color of the button to silver when the mouse is hovered over it
        button.setOnMouseEntered(e -> button.setStyle("-fx-background-color: #C0C0C0"));
        // Changing the color of the button back to lime green when the mouse is no longer hovering
        button.setOnMouseExited(e -> button.setStyle("-fx-background-color: #32CD32"));
        // Returning the created button to the calling method
        return button;
    }

    // Method to create a scene to display a message and add a button to the screen
    // The button takes us to the next scene depending upon the current level
    private void displayMessage( String labelMessage, String buttonName, int level) {
        Pane intermediatePane = new Pane();  // The outer pane for the inner panes
        drawMovingBackground(intermediatePane);  // Adding the moving background to the pane
        Label text = new Label(labelMessage);  // Label to display a message on the screen
        // Setting the font and colour of the label text and making it wrap around the text
        text.setFont(Font.font("Harrington", FontWeight.LIGHT, FontPosture.ITALIC, 70));
        text.setTextFill(Color.LAWNGREEN);
        text.setWrapText(true);
        // Creating a border pane for the label
        BorderPane labelPane = new BorderPane();
        labelPane.setPrefSize(GAME_WINDOW_WIDTH,GAME_WINDOW_HEIGHT/2.0);
        labelPane.setCenter(text);  // Adding the label at the centre of the pane
        // Creating and formatting the button that sets the stage to the next scene
        Button levelButton = createButtons(buttonName, null);
        levelButton.setFont(Font.font("Harrington"));  // Setting the font with the default size
        levelButton.setContentDisplay(ContentDisplay.CENTER);  // Aligning the content of the button to the centre
        levelButton.setPrefSize(200, 50);  // Setting the preferred size of the button
        // If the next scene is the home page scene, adding the home icon to the button
        if (level == 0) {
            ImageView homeIconIV = new ImageView(ImageCollection.getHomeIcon());
            homeIconIV.setFitWidth(20);
            homeIconIV.setFitHeight(20);
            levelButton.setGraphic(homeIconIV);
            levelButton.setContentDisplay(ContentDisplay.RIGHT);
        }
        // Creating a border pane for the button and adding the button at the centre of the pane
        BorderPane buttonPane = new BorderPane();
        buttonPane.setPrefSize(GAME_WINDOW_WIDTH,GAME_WINDOW_HEIGHT/2.0);  // Setting the size of the pane
        buttonPane.setCenter(levelButton);
        // Adding both panes to the outer Intermediate Pane
        intermediatePane.getChildren().addAll(labelPane, buttonPane);
        // Positioning the label and button panes
        labelPane.setLayoutX(0);
        labelPane.setLayoutY(100);
        buttonPane.setLayoutX(0);
        buttonPane.setLayoutY(200);
        // Displaying the freed unicorns if the player has completed all three levels
        if(gameWon) {
            // Creating an ImageView for the group of unicorns
            ImageView unicornsGroupIV = new ImageView(ImageCollection.getWinGameImage());
            // Adding the ImageView to the pane
            intermediatePane.getChildren().add(unicornsGroupIV);
            // Positioning the ImageView so that it touches the end of the pane
            unicornsGroupIV.setLayoutY(GAME_WINDOW_HEIGHT - unicornsGroupIV.getImage().getHeight());
            // Positioning the ImageView so that its centre alligned
            unicornsGroupIV.setLayoutX((GAME_WINDOW_WIDTH - unicornsGroupIV.getImage().getWidth())/2.0);
        }
        // Adding event handler to the button
        levelButton.setOnAction(e -> {
            stopBackground = true;  // Stopping the background loop
            switch(level) {
                case 1:  // When the next level is level 1, clicking the button starts the first level
                    levelOne();
                    break;
                case 2:  // When the next level is level 2, clicking the button starts the second level
                    levelTwo();
                    break;
                case 3:  // When the next level is level 3, clicking the button starts the third level
                    levelThree();
                    break;
                case 0:  // When the level is set to 0 or any other value, the button opens the Home Page
                default:
                    gameWon = false;  // gameWon is set to false when the player returns to the home page
                    SoundCollection.playHomepageAudio();  // Playing the home page audio
                    gameStage.setScene(homePageScene);  // Setting the stage to the homePageScene
                    break;
            }
        });
        // Creating the Intermediate Message Scene
        Scene intermediateScene = new Scene(intermediatePane, GAME_WINDOW_WIDTH, GAME_WINDOW_HEIGHT);
        // Setting the stage to the intermediate scene
        gameStage.setScene(intermediateScene);
    }

    // Method to display the introduction scene as well as start the narration of the introduction
    private void beginIntroduction(){
        Pane introPane = new Pane();  // Pane for the introduction
        drawMovingBackground(introPane);  // Adding the moving background to the introduction pane
        // Creating the label for the introduction text
        Label text = new Label("Once upon a time, it was all sunshine and rainbows in the world of unicorns. " +
                "But one dark night, the unicorns were attacked by witches and were captured for the magic in their" +
                " horns. All but one. All but you. You are the only unicorn left and it is your duty to save your " +
                "kingdom by destroying the witches. You must go through three waves of witch attacks to save your kind!" +
                " You will have 3 lives for each level, and will lose a life every time you get hit by a witch bullet or an " +
                "obstacle. You lose the game when you lose all your lives. But you can also pickup handy power ups to " +
                "increase your lives. You can at max have 4 lives. Good Luck!");
        // Formatting the text Label
        text.setFont(Font.font("Harrington", FontWeight.LIGHT, FontPosture.ITALIC, 30));
        text.setTextFill(Color.LAWNGREEN);
        text.setWrapText(true);
        text.setTextAlignment(TextAlignment.JUSTIFY);
        // Creating a Border pane for the text label and adding the text at the centre of it
        BorderPane textPane = new BorderPane();
        textPane.setPrefSize(GAME_WINDOW_WIDTH-110,GAME_WINDOW_HEIGHT-250);
        textPane.setCenter(text);
        textPane.setLayoutX(55);
        textPane.setLayoutY(2);
        // Creating labels to guide the player regarding the game
        Label obstacleLabel = new Label("Things You Need To Avoid:");
        Label powerupLabel = new Label("Power-up To Increase Your Lives:");
        // Positiong the labels on the screen
        obstacleLabel.setLayoutX(textPane.getLayoutX());
        obstacleLabel.setLayoutY(textPane.getLayoutY() + textPane.getPrefHeight());
        powerupLabel.setLayoutX(obstacleLabel.getLayoutX() + 450);
        powerupLabel.setLayoutY(textPane.getLayoutY() + textPane.getPrefHeight());
        // Setting the font and colour of the labels
        Font labelFont = Font.font("Harrington", 25);
        obstacleLabel.setFont(labelFont);
        obstacleLabel.setTextFill(Color.WHITESMOKE);
        powerupLabel.setFont(labelFont);
        powerupLabel.setTextFill(Color.ANTIQUEWHITE);
        // Creating ImageViews for the items to be added to the screens
        ImageView cauldron = new ImageView(ImageCollection.getCauldronImage());
        ImageView pumpkin = new ImageView(ImageCollection.getPumpkinImage());
        ImageView witchbullet = new ImageView(ImageCollection.getWitchBulletImage());
        ImageView powerup = new ImageView(ImageCollection.getPowerupImage());
        // Positioning the ImageViews
        double tempY = obstacleLabel.getLayoutY() + 40;  // used to set the y layout of the items
        cauldron.setLayoutX(75);
        cauldron.setLayoutY(tempY + 10);
        pumpkin.setLayoutX(cauldron.getLayoutX() + 80);
        pumpkin.setLayoutY(tempY);
        witchbullet.setLayoutX(pumpkin.getLayoutX() + 130);
        witchbullet.setLayoutY(tempY + 25);
        powerup.setLayoutX(witchbullet.getLayoutX() + 350);
        powerup.setLayoutY(tempY + 5);
        // Creating the home button
        Button homeButton = createButtons("RETURN TO HOMEPAGE", ImageCollection.getHomeIcon());
        homeButton.setFont(Font.font("Harrington", 20));  // Setting the font
        homeButton.setPrefSize(300,50);  // Setting the size of the button
        // Positioning the button on the screen
        homeButton.setLayoutX(GAME_WINDOW_WIDTH/3.0);
        homeButton.setLayoutY(GAME_WINDOW_HEIGHT+120-GAME_WINDOW_HEIGHT/3.0);
        // Playing the sound effects
        SoundCollection.playIntroMusic();
        SoundCollection.playIntroNarration();
        // Adding event handler to the home button
        homeButton.setOnAction(e -> {
            stopBackground = true;  // Stopping the background loop
            gameStage.setScene(homePageScene);  // Button takes us back to the home page
            SoundCollection.stopIntroMusic();  // Stopping the Intro Music
            SoundCollection.stopIntroNarration();  // Stopping the Narration
            SoundCollection.playHomepageAudio();  // Playing the homepage AudioClip
        });

        // Adding all the nodes created to the intro pane
        introPane.getChildren().addAll(textPane,obstacleLabel,powerupLabel, cauldron, pumpkin, witchbullet, powerup,homeButton);
        // Creating the introduction Scene
        Scene introScene = new Scene(introPane, GAME_WINDOW_WIDTH, GAME_WINDOW_HEIGHT);
        // Setting the stage to the intro scene
        gameStage.setScene(introScene);
    }

    // Method to add the moving background to a given pane
    private void drawMovingBackground(Pane pane) {
       stopBackground = false;
        // Creating the ImageView for the background image
        ImageView gameBackgroundIV = new ImageView(ImageCollection.getMovingBackground());
        // The starting y coordinate of the background ImageView
        double initialY = -gameBackgroundIV.getImage().getHeight() + GAME_WINDOW_HEIGHT;
        // Relocating the background ImageView so that it just touches the bottom of the screen
        gameBackgroundIV.relocate( 0, initialY);
        // Adding the background ImageView to the given pane
        pane.getChildren().add(gameBackgroundIV);
        // Timer loop for scrolling the background
        AnimationTimer backgroundLoop = new AnimationTimer() {
            @Override
            public void handle(long l) {
                // Stopping the background loop
                if(stopBackground)
                    this.stop();
                // Updating the y coordinate of the background
                double y = gameBackgroundIV.getLayoutY() + 1;
                gameBackgroundIV.setLayoutY(y);
                // Repositioning the background back to its starting position when the image has completely scrolled down
                if( y >= 0)
                    gameBackgroundIV.setLayoutY(initialY);
            }
        };
        // Starting the background loop
        backgroundLoop.start();
    }

    // Method to add a pane to the home page
    private void displayPaneOnHome(Image image){
        Pane pane = new Pane();  // Pane to be added to the home page
        ImageView infoIV = new ImageView(image);  // Creating ImageView for the given image
        // Setting the width and height
        infoIV.setFitWidth(400);
        infoIV.setFitHeight(300);
        // Adding the ImageView to the pane
        pane.getChildren().add(infoIV);
        // Positioning infoIV
        infoIV.setLayoutX((GAME_WINDOW_WIDTH - infoIV.getFitWidth())/2);
        infoIV.setLayoutY(50 + (GAME_WINDOW_HEIGHT - infoIV.getFitHeight())/2);
        // Creating a button to close i.e remove the added pane
        Button closeButton = new Button("X");
        // Setting width
        closeButton.setPrefWidth(20);
        // Setting color of the text
        closeButton.setTextFill(Color.ANTIQUEWHITE);
        // Setting color of the button to dark red
        closeButton.setStyle("-fx-background-color: #8B0000");
        // Adding the button the the pane
        pane.getChildren().add(closeButton);
        // Positioning the button
        closeButton.setLayoutX(infoIV.getFitWidth() + infoIV.getLayoutX() - closeButton.getPrefWidth() - 4);
        closeButton.setLayoutY(infoIV.getLayoutY());
        // Adding event listener to the button
        closeButton.setOnAction(e -> homePagePane.getChildren().remove(pane));
        // Adding the pane to the homepage
        homePagePane.getChildren().add(pane);
    }

    // Method to start the first level
    private void levelOne() {
        Pane level1pane = new Pane();  // Creating the pane for level 1
        drawMovingBackground(level1pane);  // Adding the moving background to the level1pane
        createUnicorn(level1pane);  // Adding the unicorn Player to the pane
        // Adding witch arrays to the pane
        initializeWitches(witchArray1, level1pane);
        initializeWitches(witchArray2, level1pane);
        // Positioning the witch arrays
        try {
            for (int i = 0; i < 5; i++) {
                witchArray1[i].getCharacterIV().setLayoutX((i * 130) + 170);
                witchArray1[i].getCharacterIV().setLayoutY(10);
                witchArray2[i].getCharacterIV().setLayoutX((i * 130) + 230);
                witchArray2[i].getCharacterIV().setLayoutY(118);
            }
        }
        // Catching index out of bound exception
        catch (IndexOutOfBoundsException e) {
            e.printStackTrace();
            System.out.println("Error accessing Witch Array.");
        }
        // Creating the level one scene
        Scene level1scene = new Scene(level1pane, GAME_WINDOW_WIDTH, GAME_WINDOW_HEIGHT);
        // Calling the update level
        update(level1pane, level1scene, "LEVEL 1 COMPLETE!", "CONTINUE TO LEVEL TWO", 2, 30, witchArray1, witchArray2);
        // Setting the stage to the level1scene
        gameStage.setScene(level1scene);
    }

    // Method to start the second level
    private void levelTwo() {
        Pane level2pane = new Pane();  // Creating the pane for level 2
        drawMovingBackground(level2pane);  // Adding the moving background to the level2pane
        createUnicorn(level2pane);  // Adding the unicorn Player to the pane
        // Adding witch arrays to the pane
        initializeWitches(witchArray1, level2pane);
        initializeWitches(witchArray2, level2pane);
        initializeWitches(witchArray3, level2pane);
        // Positioning the witches
        try {
            for (int i = 0; i < 5; i++) {
                witchArray1[i].getCharacterIV().setLayoutX((i * 130) + 170);
                witchArray1[i].getCharacterIV().setLayoutY(10);
                witchArray2[i].getCharacterIV().setLayoutX((i * 130) + 150);
                witchArray2[i].getCharacterIV().setLayoutY(118);
                witchArray3[i].getCharacterIV().setLayoutX((i * 130) + 230);
                witchArray3[i].getCharacterIV().setLayoutY(226);
            }
        }
        // Catching exception
        catch (IndexOutOfBoundsException e) {
            e.printStackTrace();
            System.out.println("Error accessing witch Array.");
        }

        // Creating the scene for level two
        Scene level2scene = new Scene(level2pane, GAME_WINDOW_WIDTH, GAME_WINDOW_HEIGHT);
        // Calling the update method
        update(level2pane, level2scene, "LEVEL 2 COMPLETE!", "CONTINUE TO LEVEL THREE", 3, 25, witchArray1, witchArray2, witchArray3);
        // Making the witches move on the screen
        moveWitchesLeft(witchArray1);
        moveWitchesRight(witchArray3);
        // Setting the stage to the level2scene
        gameStage.setScene(level2scene);
    }

    // Method to start the third level
    private void levelThree() {
        Pane level3pane = new Pane(); // Creating the pane for level 3
        drawMovingBackground(level3pane);  // Adding the moving background to the level3pane
        createUnicorn(level3pane);  // Adding the unicorn Player to the pane
        // Adding witch arrays to the pane
        initializeWitches(witchArray1, level3pane);
        initializeWitches(witchArray2, level3pane);
        initializeWitches(witchArray3, level3pane);
        initializeWitches(witchArray4, level3pane);
        try {
            // Positioning the witches
            for (int i = 0; i < 5; i++) {
                witchArray1[i].getCharacterIV().setLayoutX((i * 130) + 170);
                witchArray1[i].getCharacterIV().setLayoutY(10);
                witchArray2[i].getCharacterIV().setLayoutX((i * 130) + 150);
                witchArray2[i].getCharacterIV().setLayoutY(118);
                witchArray3[i].getCharacterIV().setLayoutX((i * 130) + 230);
                witchArray3[i].getCharacterIV().setLayoutY(226);
                witchArray4[i].getCharacterIV().setLayoutX((i * 130) + 230);
                witchArray4[i].getCharacterIV().setLayoutY(334);
            }
        }
        // Catching exception
        catch (IndexOutOfBoundsException e) {
            e.printStackTrace();
            System.out.println("Error accessing witch array.");
        }
        // Creating the scene for level 3
        Scene level3scene = new Scene(level3pane, GAME_WINDOW_WIDTH, GAME_WINDOW_HEIGHT);
        // Calling the update method
        update(level3pane, level3scene, "YOU WON THE GAME!", "RETURN TO HOMEPAGE", 0, 20, witchArray1, witchArray2, witchArray3, witchArray4);
        // Making the witches move
        moveWitchesLeft(witchArray1);
        moveWitchesRight(witchArray2);
        moveWitchesLeft(witchArray3);
        moveWitchesRight(witchArray4);
        // Setting the stage to the level3scene
        gameStage.setScene(level3scene);
    }

    // Method that continuously updates all entities and detects collisions i.e the main game loop
    private void update(Pane levelPane, Scene levelScene, String levelWinMessage, String nextLevelButtonName, int nextLevel, int levelEase, Witch[]... witchArrays) {
        unicornPlayer.handleKeyInputs(levelScene, witchArrays);  //making the unicorn respond to key inputs
        Character.setNotShooting(false);  // Setting Not Shooting boolean for all characters as false
        Item.setNotMoving(false);  // Setting not Moving boolean for all Items as false
        // The main game loop:
        AnimationTimer gameLoop = new AnimationTimer() {
            @Override
            public void handle(long l) {
                unicornPlayer.move(); // Making the unicorn move
                createObstacles(levelPane);  // Adding obstacles to the pane
                createPowerup(levelPane);  // Adding Powerups to the pane
                int deadWitchesCount = 0;  // Number of dead witches
                int totalWitches = 0;  // Number of total witches
                for(Witch[] witchArray: witchArrays) {
                    shootWitchBullets(witchArray, levelEase);  // Making random witches shoot bullets
                    totalWitches = totalWitches + witchArray.length;
                    // Calculating the number of dead witches
                    for(Witch witch: witchArray) {
                        if(witch.isDead())
                            deadWitchesCount++;  // Incrementing dead witch count if witch is dead
                    }  // end of inner for
                }  // end of outer for
                // As soon as all the witches die or the player dies, all the loops are stopped
                if(deadWitchesCount >= totalWitches || unicornPlayer.isDead()) {
                    Item.setNotMoving(true);
                    Character.setNotShooting(true);
                    stopBackground = true;
                    this.stop();
                    // Message displayed if the player loses the game
                    if(unicornPlayer.isDead()) {
                        SoundCollection.playGameOver();  // Play the game over AudioClip
                        // Display the message for the next scene
                        displayMessage("YOU LOST! GAME OVER!", "RETURN TO HOMEPAGE", 0);
                    }
                    // Message for the next level displayed if the player completes the level
                    else if(deadWitchesCount >= totalWitches) {
                        // If the next level is 0 i.e the third level has been completed
                        if(nextLevel == 0) {
                            gameWon = true;
                            SoundCollection.playGameWon();  // Play the game won AudioClip if the game is complete
                        }
                        else  // If the game is not complete yet
                            SoundCollection.playLevelTransition();  // Play the level transition AudioClip
                        // Display the message for the next scene
                        displayMessage(levelWinMessage, nextLevelButtonName, nextLevel);
                    }  // end of inner if
                }  // end of outer if
            }
        };  // End of loop
        gameLoop.start();  // Starting the game loop
    }

    // Method to create a new unicorn object and add it to the given pane
    public void createUnicorn(Pane pane) {
        // Creating the player unicorn
        unicornPlayer = new Unicorn(pane);
        // adding the unicorn ImageView and the LivesPane to the pane
        pane.getChildren().addAll(unicornPlayer.getCharacterIV(), unicornPlayer.getLivesPane());
        // Positioning the unicorn
        unicornPlayer.getCharacterIV().setLayoutX((GAME_WINDOW_WIDTH/2.0) - 50);
        unicornPlayer.getCharacterIV().setLayoutY(GAME_WINDOW_HEIGHT - 70);
        // Positioning the livesPane
        unicornPlayer.getLivesPane().setLayoutX(0);
        unicornPlayer.getLivesPane().setLayoutY(0);
    }

    // Method to initialize a witch array and add the witches to the given pane
    private void initializeWitches(Witch[] witchArray, Pane pane) {
        for(int i = 0; i<witchArray.length; i++) {
            // Creating witch object
            witchArray[i] = new Witch(pane);
            // Adding the witch object to the pane
            pane.getChildren().add(witchArray[i].getCharacterIV());
        }
    }

    // Method to move an array of the witches to the left until they go out of the screen
    private void moveWitchesLeft(Witch[] witchArray){
        // Timer loop to move the witches
        AnimationTimer moveWitchesLeftLoop = new AnimationTimer() {
            @Override
            public void handle(long l) {
                // Condition to stop the loop
                if(Witch.isNotShooting()) {
                    this.stop();
                }
                // If the witches go out of the screen, make them start moving to the right
                else if (witchArray[0].getCharacterIV().getLayoutX()<=50){
                    this.stop();
                    moveWitchesRight(witchArray);
                }
                for (Witch witch : witchArray) {
                    // Make each witch in the array move to the left
                    witch.moveLeft();
                }
            }
        };
        // Start the loop
        moveWitchesLeftLoop.start();
    }

    // Method to move an array of the witches to the right until they go out of the screen
    private void moveWitchesRight(Witch[] witchArray){
        // Timer loop to move the witches
        AnimationTimer moveWitchesRightLoop = new AnimationTimer() {
            @Override
            public void handle(long l) {
                // Condition to stop the loop
                if (Witch.isNotShooting())
                    this.stop();
                    // If the witches go out of the screen, make them start moving to the left
                else if (witchArray[witchArray.length-1].getCharacterIV().getLayoutX()>=GAME_WINDOW_WIDTH-100){
                    this.stop();
                    moveWitchesLeft(witchArray);
                }
                for (Witch witch : witchArray) {
                    // Make each witch in the array move to the right
                    witch.moveRight();
                }
            }
        };
        // start the loop
        moveWitchesRightLoop.start();
    }

    // Method to randomly make a random witch out of a given array shoot a bullet.
    // Every one out of a given number(level ease) of times this method is called, a witch will shoot a bullet
    private void shootWitchBullets(Witch[] witchArray, int levelEase) {
        Random rand = new Random();  // Random object for generating random numbers
        int randomIndex;  // Randomly generated index for the witch array
        // This condition ensures that every one out of a given (LevelEase) number of times this method is called,
        // a random witch, if it is not dead will shoot a bullet
        if(rand.nextInt(levelEase)==5) {
            randomIndex = rand.nextInt(witchArray.length);
            if(!witchArray[randomIndex].isDead())
                witchArray[randomIndex].shootBullets(unicornPlayer);
        }
    }

    // Method to randomly create an Obstacle and add it to the pane
    private void createObstacles(Pane pane){
        Random rand = new Random();  // Random object for generating random numbers
        // The following condition will ensure that every 1 out of 100 times this method is called,
        // an obstacle will be created
        if(rand.nextInt(100)==5) {
            int type = rand.nextInt(2) + 1; // The type of obstacle created will be either type 1 or 2
            Obstacle obstacle = new Obstacle(type, pane);  // Creating a new obstacle
            obstacle.addToPane();  // Adding the obstacle object to the pane
            obstacle.move();  // Making the obstacle object move on the screen
            // The loop to detect collisions of the obstacle object with the unicorn and unicorn bullets
            AnimationTimer collisionLoop = new AnimationTimer() {
                @Override
                public void handle(long l) {
                    obstacle.detectCollisionWithCharacter(unicornPlayer);
                    obstacle.detectCollisionWithUnicornBullets(unicornPlayer);
                    // Condition to stop the loop
                    if (obstacle.isDestroyed() || Obstacle.isNotMoving())
                        this.stop();
                }
            };  // End of the loop
            collisionLoop.start();  // Starting the collision loop
        }
    }

    // Method to randomly create a Powerup and add it to the pane
    private void createPowerup(Pane pane){
        Random rand = new Random();  // Random object for generating random numbers
        // The following condition will ensure that every 1 out of 400 times this method is called,
        // a Powerup will be created
        if(rand.nextInt(400)==5) {
            Powerup powerup = new Powerup(pane);  // Creating a new powerup
            powerup.addToPane();  // Adding the powerup object to the pane
            powerup.move();  // Making the powerup object move on the screen
            // The loop to detect collisions of the obstacle object with the unicorn
            AnimationTimer collisionLoop = new AnimationTimer() {
                @Override
                public void handle(long l) {
                    powerup.detectCollisionWithCharacter(unicornPlayer);
                    if (powerup.isDestroyed() || Powerup.isNotMoving())  // Condition to stop the loop
                        this.stop();
                }
            };  // End of the loop
            collisionLoop.start();  // Starting the collision loop
        }
    }

    // The main method
    public static void main(String[] args) {
        launch(args);
    }
}  // Ending brace of class SpellBound