package endsemesterproject;

import javafx.animation.AnimationTimer;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

/** Class Unicorn that inherits from the class Character **/
public class Unicorn extends Character {
    private final int MAX_LIVES = 4;  // Maximum number of lives of the unicorn
    private int lives;  // Lives of the unicorn during the game
    private VBox livesPane;  // A VBox pane for the life IVs
    private ImageView[] lifeIVs;  // Array of Life ImageViews
    private Bullet[] bulletsArray = new Bullet[1000];  // Array to store the Bullets shot by the unicorn
    private int bulletIndex = 0;  // Index to determine where to add the new Bullet in the bulletsArray
    private boolean leftKey, rightKey, shootKey;  // Boolean variables for handling key inputs

    // Constructor with one Pane argument
    public Unicorn(Pane pane) {
        super(ImageCollection.getUnicornLeftImage(), pane);  // Call to constructor of super class
        livesPane = new VBox();  // Creating the livesPane
        lives = MAX_LIVES - 1;  // Setting the starting lives to one less than maximum possible lives
        this.createLifeIVs();  // Calling method to initialize the lifeIVs array and add them to pane
    }

    // Method to initialize the lifeIVs array and add them to pane
    private void createLifeIVs() {
        lifeIVs = new ImageView[MAX_LIVES];  // Creating array for MAX_LIVES number of ImageViews
        for(int i=0; i<lifeIVs.length; i++) {
            lifeIVs[i] = new ImageView(ImageCollection.getLivesImage());  // Creating ImageView
            lifeIVs[i].setFitWidth(40);  // Setting width
            lifeIVs[i].setFitHeight(44);  // Setting height
        }

        // Adding current number of lives' ImageViews to the pane
        try {
            for (int i = 0; i < lives; i++) {
                livesPane.getChildren().add(lifeIVs[i]);
            }
        }
        // Catching exception
        catch (IndexOutOfBoundsException e) {
            e.printStackTrace();
            System.out.println("Error adding life IV to the Pane.");
        }
    }

    // Adding event handlers to the given scene
    public void handleKeyInputs(Scene scene, Witch[]... witchArrays){
        // Setting the scene to handle events of keys being pressed
        scene.setOnKeyPressed(e-> {
            // Making boolean variable corresponding to the pressed key as true
            switch (e.getCode()) {
                case LEFT:
                    leftKey = true;
                    break;
                case RIGHT:
                    rightKey = true;
                    break;
                case SPACE:
                    shootKey = true;
                    shootBullets(witchArrays);  // Shooting bullets at given witches if SPACE is pressed
                    break;
            }
        });
        // Setting scene to handle events of keys being released
        scene.setOnKeyReleased(e -> {
            // Making boolean variable corresponding to the pressed key as false
            switch (e.getCode()) {
                case LEFT:
                    leftKey = false;
                    break;
                case RIGHT:
                    rightKey = false;
                    break;
                case SPACE:
                    shootKey = false;
                    break;
            }
        });
    }

    // Method to move the unicorn
    public void move() {
        // If the LEFT key is pressed
        if (leftKey == true) {
            setxCoord(getCharacterIV().getLayoutX());  // Current xCoord of Unicorn
            getCharacterIV().setImage(ImageCollection.getUnicornLeftImage());  // Making the Unicorn face left
            // Moving the Unicorn ImageView move 5 pixels to the left if it is not going out of the screen
            if (getCharacterIV().getLayoutX() >= 5)
                getCharacterIV().setLayoutX(getCharacterIV().getLayoutX() - 5);
        }
        // If the RIGHT key is pressed
        if(rightKey == true) {
            setxCoord(getCharacterIV().getLayoutX());  // Current xCoord of Unicorn
            getCharacterIV().setImage(ImageCollection.getUnicornRightImage());  // Making the Unicorn face right
            // Moving the Unicorn ImageView move 5 pixels to the right if it is not going out of the screen
            if (getCharacterIV().getLayoutX()<=getCharacterPane().getWidth() - 45)
                getCharacterIV().setLayoutX(getCharacterIV().getLayoutX() + 5);
        }
    }

    // Method to make the unicorn shoot a bullet at the given arrays of witches
    public void shootBullets( Witch[]... witchArrays) {
        if(shootKey == true) {  // if the shoot key (SPACE) is pressed
            SoundCollection.playUnicornShoot();  // Playing audio clip of unicorn bullet being shot
            // creating a new unicorn bullet with the same pane as the shooting unicorn
            UnicornBullet unicornBullet = new UnicornBullet(this);
            unicornBullet.addToPane();  // Adding the bullet to the pane
            unicornBullet.move();  // Making the bullet move on the pane
            updateBulletsArray(unicornBullet);  // Updating the bullets array
            // Loop to detect collisions of the created bullet with the given witches
            AnimationTimer collisionLoop = new AnimationTimer() {
                @Override
                public void handle(long l) {
                    for(Witch[] witchArray: witchArrays) {
                        for (Witch witch : witchArray) {
                            // Condition to stop the loop
                            if(unicornBullet.isDestroyed() || Character.isNotShooting()) {
                                this.stop();
                                break;
                            }
                            // detect collision of the witch with the created bullet
                            unicornBullet.detectCollisionWithCharacter(witch);
                        }  // ending brace of inner for
                    }  // ending brace of outer for
                }  // ending brace of handle method
            };
            collisionLoop.start();  // Starting the loop
        }  // Ending brace of if
    }  // Ending brace of method ShootBullets

    // Method to update the bulletsArray
    private void updateBulletsArray(UnicornBullet unicornBullet) {
        if(bulletIndex >=bulletsArray.length) {  // If the array is full
            for(bulletIndex = 0; bulletIndex <bulletsArray.length; bulletIndex++) {  // reset index to zero
                // Assign the bullet to the array at bulletIndex if the current bullet in the array is already destroyed
                if(bulletsArray[bulletIndex].isDestroyed()) {
                    bulletsArray[bulletIndex] = unicornBullet;
                    break;
                }
            }
        }
        else {  // If the array is not full then simply assign the bullet at bullet index
            bulletsArray[bulletIndex] = unicornBullet;
            bulletIndex++; // increment bulletIndex
        }
    }

    @Override
    // Method for what happens when the Unicorn collides with an Item
    public void onCollision(Item item){
        if (item instanceof Powerup)  // If the collided Item is a Powerup
            this.addLife();  // Add a life to the unicorn's lives
        else if (item instanceof BadItem)  // If the collided Item is a BadItem
            this.removeLife();  // Remove a life from the unicorn's lives

    }

    // Method to add a life
    private void addLife() {
        if (lives<MAX_LIVES) {  // If lives arent max
            SoundCollection.playPickupPowerup();  // Play the audioClip of powerup picked up
            lives = lives + 1;  // Increment lives
            livesPane.getChildren().add(lifeIVs[lives - 1]);  // add a lifeIV to the pane
        }
    }

    // Method to remove a life
    private void removeLife() {
        if(lives>0) {  // If there is more than one life
            SoundCollection.playUnicornLoseLife();  // Play life lost audio
            livesPane.getChildren().remove(lifeIVs[lives - 1]);  // remove a lifeIV from the pane
            lives = lives - 1;  // decrement lives
        }
        if(lives==0) {  // If there is only one life left
            SoundCollection.playUnicornDestroyed();  // Play the unicorn destroyed audio
            getCharacterPane().getChildren().remove(getCharacterIV());  // remove the unicorn from the pane
            setIsDead(true);  // Set unicorn isDead to true
        }
    }

    // Getter method for the bulletsArray
    public Bullet[] getBulletsArray() {
        return bulletsArray;
    }

    // Getter method for the livesPane
    public VBox getLivesPane() {
        return livesPane;
    }

}  // Ending brace of class Unicorn
