Github Link:
Project Name: SpellBound
Description: 2-Dimentional Vertically Scrolling Shooter Game
Features:
3 Levels with Increasing difficulty.
Powerups to help the player.
Obstacles to make the game harder.
Narration and other sound effects.
Instructions:
SpellBound is the main class of the project. Run SpellBound.
The HomePage will open up.
Click introduction button to see the introduction.
Click the controls button to see the controls.
Click Play and then click Begin Game to start the game.
The Game consists of three levels.
Use the left and right arrow keys to move.
Press spacebar to shoot.
Kill all the witches to complete a level.
Complete all three levels to win the game.

Note: A separate video of the entire gameplay has been added into the folder.